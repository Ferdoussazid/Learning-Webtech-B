function validateDate() 
{
    let dateInput = document.getElementById('date');
    let dateValue = dateInput.value.trim();
    let dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
    let [, day, month, year] = dateValue.match(dateRegex);
    let dayInt = parseInt(day, 10);
    let monthInt = parseInt(month, 10);
    let yearInt = parseInt(year, 10);

    if (dateValue.length === 0) 
    {
      alert("Date cannot be empty.");
      return false;
    }

    
    else if (!dateRegex.test(dateValue)) 
    {
      alert("Please enter a valid date in the format dd/mm/yyyy.");
      return false;
    }

    

    else if (dayInt < 1 || dayInt > 31 || monthInt < 1 || monthInt > 12 || yearInt < 1900 || yearInt > 2016) 
    {
      alert("Please enter a valid date (dd: 0-31, mm: 1-12, yyyy: 1900-2016).");
      return false;
    }

    else
    {
    return true;
    }
  }