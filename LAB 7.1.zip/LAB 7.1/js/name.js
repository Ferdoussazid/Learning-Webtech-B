function validateName() 
{
    let nameInput = document.getElementById('name');
    let nameValue = nameInput.value.trim();
    let words = nameValue.split(/\s+/);

    if (nameValue.length === 0) 
    {
      alert("Name cannot be empty.");
      return false;
    }


    else if (words.length < 2) 
    {
      alert("Name must contain at least two words.");
      return false;
    }

    else if (!/^[a-zA-Z.-]+$/.test(nameValue)) 
    {
      alert("Name can only contain letters (a-z or A-Z), dot (.), or dash (-).");
      return false;
    }


    else if (!/^[a-zA-Z]/.test(nameValue)) 
    {
      alert("Name must start with a letter.");
      return false;
    }

    else
  {
    return true;
  }
} 