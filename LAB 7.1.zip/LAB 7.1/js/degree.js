function validateDegree() 
{
    let SSCInput = document.getElementById('SSC');
    let HSCInput = document.getElementById('HSC');
    let BScInput = document.getElementById('BSc');

    
    if (!SSCInput.checked && !HSCInput.checked && !BScInput.checked) 
    {
      alert("Please select at least one degree option.");
      return false;
    }

    else
    {
    return true;
    }
  }