function validateGender() 
{
    let maleInput = document.getElementById('male');
    let femaleInput = document.getElementById('female');
    let otherInput = document.getElementById('other');

    
    if (!maleInput.checked && !femaleInput.checked && !otherInput.checked) 
    {
      alert("Please select a gender option.");
      return false;
    }

   else
   {
    return true;
   }
  }