function validateEmail() 
{
    let emailInput = document.getElementById('email');
    let emailValue = emailInput.value.trim();
    let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    
    if (emailValue.length === 0) 
    {
      alert("Email cannot be empty.");
      return false;
    }
    
    else if (!emailRegex.test(emailValue)) 
    {
      alert("Please enter a valid email address (e.g., anything@example.com).");
      return false;
    }

    else 
    {
    return true;
    }
  }