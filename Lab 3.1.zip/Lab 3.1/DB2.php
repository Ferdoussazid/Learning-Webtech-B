<?php

if (isset($_POST['submit'])) 
{
    $D1 = $_POST['dob'];
    echo $D1;
}
?>

<html>
<!-- <p>as</p> -->

</html>