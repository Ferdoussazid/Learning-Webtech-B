<?php

if (isset($_POST['submit'])) 
{
    $G1 = $_POST['gender'];
    echo $G1;
}