<?php

if (isset($_POST['submit'])) 
{
    $E1 = $_POST['email'];
    echo $E1;
}
?>


<html>

<head>
    <title>Email</title>
</head>

<body>
    <form method="post">
        <fieldset>
            <legend>E-mail</legend>
            Email : <input type="email" name="email" value="" />
            <input type="button" placeholder="i" title="hint: sample@example.com">
            <hr>
            <input type="submit" name="submit" value="Submit" />
        </fieldset>
    </form>
</body>

</html>