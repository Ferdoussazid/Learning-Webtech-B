<?php

if (isset($_POST['submit'])) 
{
    $DB1 = $_POST['dob'];
    echo $DB1;
}
?>


<html>

<head>
    <title>Date of Birth</title>
</head>

<body>
    <form method="post">
        <fieldset>
            <legend>Date of Birth</legend>
            dob : <input type="date" name="dob  " value="" />
            <hr>
            <input type="submit" name="submit" value="Submit" />
        </fieldset>
    </form>
</body>

</html>