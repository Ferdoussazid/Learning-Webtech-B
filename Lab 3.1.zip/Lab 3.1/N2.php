<?php

if (isset($_POST['submit'])) 
{
    $name = $_POST['name'];
    echo $name;
}

?>

<html>

<!-- <p>as</p> -->

</html>