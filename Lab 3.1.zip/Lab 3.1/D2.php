<?php

if (isset($_POST['submit'])) 
{
    $D1 = $_POST['degree'];
    echo $D1;
}