<?php

if (isset($_POST['submit'])) {
    $B1 = $_POST['bg'];
    echo $B1;
}