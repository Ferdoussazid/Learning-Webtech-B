<?php

if (isset($_POST['submit'])) 
{
    $E1 = $_POST['email'];
    echo $E1;
}
?>

<html>
<!-- <p>as</p> -->

</html>