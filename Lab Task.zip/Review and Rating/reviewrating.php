<!DOCTYPE html>
<html>
<head>
  <title>Movie Rating and Review - Submission</title>
</head>
<body>
  <h1>Movie Rating and Review - Submission</h1>

  <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") 
  {
    $movie_title = $_POST["movie_title"];
    $rating = $_POST["rating"];
    $review = $_POST["review"];

    $conn = mysqli_connect('localhost', 'root', '', 'LabTask');

    $sql = "insert into Movies values('$movie_title', '$rating', '$review')";
    if(mysqli_query($conn, $sql) === true) echo "Rated Successfully";

  }
  ?>

</body>
</html>
